INSERT INTO `tb_screenshots`(`id`, `image_path`, `image_name`) VALUES (1, '/assets/images/3d45ceafdc666218554118a0aeb1d3e4.jpg', '3d45ceafdc666218554118a0aeb1d3e4.jpg');
INSERT INTO `tb_screenshots`(`id`, `image_path`, `image_name`) VALUES (2, '/assets/images/e4cfde6d5ae17046f6606820a2dc1023.jpg', 'e4cfde6d5ae17046f6606820a2dc1023.jpg');
INSERT INTO `tb_screenshots`(`id`, `image_path`, `image_name`) VALUES (3, '/assets/images/0844e8c617981648c6fb6f7da8907780.png', '0844e8c617981648c6fb6f7da8907780.png');
